/*
 *  GHSimulatorMocks.h
 *  GHUnit
 *
 *  Created by Johannes Rudolph on 06.10.09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#import "GHMockCLLocationManager.h"
#import "GHMockNSHTTPURLResponse.h"
#import "GHMockNSURLConnection.h"